import pandas as pd  # Importer la bibliothèque pandas pour la manipulation et l'analyse des données.
from sklearn.model_selection import train_test_split  # Importer une fonction pour diviser les données en ensembles d'entraînement et de test.
from sklearn.preprocessing import LabelEncoder  # Importer des outils pour le prétraitement des données (normalisation et encodage).
from sklearn.svm import SVC  # Importer le classifieur basé sur les machines à vecteurs de support (SVM).
from sklearn.metrics import classification_report, confusion_matrix  # Importer des métriques pour évaluer les performances.
import matplotlib.pyplot as plt;
import seaborn as sns
import pickle
import sys
import json
import pandas as pd
import pickle
from sklearn.preprocessing import StandardScaler
from flask import Flask, request, jsonify
import joblib
from flask_cors import CORS
import os
print(os.getcwd())
os.chdir("C:/Users/IMANE/Desktop/Project_web4.0/Model_AI")  # Replace with the correct path

data1 = pd.read_csv("conn.csv")
data1.dropna(inplace=True)

data1.drop(columns=['ts', 'uid', 'id.orig_p', 'id.resp_h', 'id.resp_p','history','tunnel_parents'], inplace=True)
X1=data1

file_path1 = r'C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/features.pkl'  # Specify the desired path
with open(file_path1, 'rb') as file:
    features= pickle.load(file)
    
file_path2 = r'C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/scaler.pkl' 
with open(file_path2, 'rb') as file:
    scaler = pickle.load(file)

X1 =pd.get_dummies(X1, columns=['proto', 'service', 'conn_state','local_resp','local_orig'], drop_first=True)

# Align test data to training features
X1 = X1.reindex(columns=features, fill_value=0)

X1= scaler.transform(X1)


#########to call and test model
# Specify the path to your saved model
file_path3 = r'C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/model.pkl' 

# Load the saved model
with open(file_path3, 'rb') as file:
    model = pickle.load(file)

# Use the model to make predictions
predictions = model.predict(X1)

print(predictions)


# Define attack mapping inverse
attack_mapping = {0: "Normal", 1: "DoS", 2: "Portscan"}

# Create a new DataFrame for results
results_df = data1.copy()  # Copy original data to preserve it
results_df['Predicted Attack Type'] = [attack_mapping[pred] for pred in predictions]
# data2=results_df['Predicted Attack Type']
# Output the results DataFrame
# print(data2)  # Display predictions 

attack_data = results_df[results_df["Predicted Attack Type"] != "Normal"]

print("\nCritical Alerts Detected with Source IPs:")
print(attack_data[['id.orig_h', 'Predicted Attack Type']])


# Save to CSV


output_csv = r"C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/Alerts_with_IPs.csv"
attack_data[['id.orig_h', 'Predicted Attack Type']].to_csv(output_csv, index=False)
print(f"Log file with source IPs saved to: {output_csv}")



# Charger le modèle et les objets nécessaires
model_path = 'C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/model.pkl'
features_path = 'C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/features.pkl'
scaler_path = 'C:/Users/IMANE/Desktop/Project_web4.0/Model_AI/scaler.pkl'

try:
    with open(model_path, 'rb') as file:
        model = pickle.load(file)
    
    with open(features_path, 'rb') as file:
        features = pickle.load(file)
    
    with open(scaler_path, 'rb') as file:
        scaler = pickle.load(file)
    
except FileNotFoundError as e:
    print(json.dumps({"error": f"File not found: {str(e)}"}))
    sys.exit(1)
except Exception as e:
    print(json.dumps({"error": f"Error loading models: {str(e)}"}))
    sys.exit(1)

# Mapping des attaques
attack_mapping = {0: "Normal", 1: "DoS", 2: "Portscan"}
# Importer les bibliothèques nécessaires
import os  # Bibliothèque pour interagir avec le système de fichiers
import sys  # Utilisé pour gérer les erreurs et terminer le programme si nécessaire
import json  # Pour manipuler les données JSON
import pickle  # Pour sauvegarder et charger des objets Python sérialisés (modèles, scalers, etc.)
import pandas as pd  # Pour manipuler les données tabulaires
from flask import Flask, jsonify  # Flask pour créer une application web et jsonify pour renvoyer des réponses JSON
from flask_cors import CORS  # Pour permettre les requêtes CORS (Cross-Origin Resource Sharing)

# Définir le chemin de base où tous les fichiers liés au projet sont stockés
BASE_PATH = r"C:\Users\IMANE\Desktop\projet_web_final\Model_AI"

# Changer le répertoire de travail vers BASE_PATH
os.chdir(BASE_PATH)

# Initialiser l'application Flask
app = Flask(__name__)  # Crée une instance de l'application Flask
CORS(app)  # Active les requêtes CORS pour permettre les appels depuis d'autres domaines

# Définir les chemins pour les fichiers nécessaires
MODEL_PATH = os.path.join(BASE_PATH, "model.pkl")  # Chemin du modèle enregistré
FEATURES_PATH = os.path.join(BASE_PATH, "features.pkl")  # Chemin des caractéristiques utilisées lors de l'entraînement
SCALER_PATH = os.path.join(BASE_PATH, "scaler.pkl")  # Chemin de l'objet scaler utilisé pour la normalisation
ALERTS_CSV_PATH = os.path.join(BASE_PATH, "Alerts_with_IPs.csv")  # Chemin du fichier CSV pour les alertes

# Charger le modèle, les caractéristiques et le scaler
try:
    # Charger le modèle
    with open(MODEL_PATH, 'rb') as file:
        model = pickle.load(file)
    
    # Charger les caractéristiques utilisées lors de l'entraînement
    with open(FEATURES_PATH, 'rb') as file:
        features = pickle.load(file)
    
    # Charger l'objet scaler pour normaliser les données
    with open(SCALER_PATH, 'rb') as file:
        scaler = pickle.load(file)

# Gestion des erreurs si un fichier est introuvable
except FileNotFoundError as e:
    print(json.dumps({"error": f"File not found: {str(e)}"}))  # Afficher un message d'erreur au format JSON
    sys.exit(1)  # Arrêter le programme avec un code d'erreur
except Exception as e:
    print(json.dumps({"error": f"Error loading models: {str(e)}"}))  # Afficher tout autre type d'erreur
    sys.exit(1)

# Mapping des types d'attaques
ATTACK_MAPPING = {0: "Normal", 1: "DoS", 2: "Portscan"}  # Associe chaque classe prédite à une description

# Définir une route API pour obtenir les alertes
@app.route('/get_alerts', methods=['GET'])  # Route pour les requêtes GET
def get_alerts():
    try:
        # Lire les alertes depuis le fichier CSV généré
        alerts = pd.read_csv(ALERTS_CSV_PATH)
        
        # Convertir le DataFrame en un dictionnaire au format JSON
        alerts_json = alerts.to_dict(orient='records')
        
        # Renvoyer les alertes au format JSON avec un code de statut 200 (succès)
        return jsonify({"alerts": alerts_json}), 200
    except Exception as e:
        # En cas d'erreur, renvoyer un message d'erreur avec un code de statut 500 (erreur serveur)
        return jsonify({"error": str(e)}), 500

# Point d'entrée principal de l'application
if __name__ == '__main__':
    # Démarrer l'application Flask sur le port 5000
    app.run(host='0.0.0.0', port=5000)
