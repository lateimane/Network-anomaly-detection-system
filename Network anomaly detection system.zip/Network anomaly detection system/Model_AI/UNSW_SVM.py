# =============================================================================
# Model training
# =============================================================================

# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 20:27:25 2024

@author: Administrator
"""
import numpy as np
import pandas as pd  # Importer la bibliothèque pandas pour la manipulation et l'analyse des données.
from sklearn.model_selection import train_test_split  # Importer une fonction pour diviser les données en ensembles d'entraînement et de test.
from sklearn.preprocessing import StandardScaler, LabelEncoder  # Importer des outils pour le prétraitement des données (normalisation et encodage).
from sklearn.svm import SVC  # Importer le classifieur basé sur les machines à vecteurs de support (SVM).
from sklearn.metrics import classification_report, confusion_matrix  # Importer des métriques pour évaluer les performances.
import matplotlib.pyplot as plt;import seaborn as sns
from imblearn.over_sampling import SMOTE
import pickle
# Load the dataset
data =pd.read_csv(r"C:\Users\Administrator\Downloads\PDD/final model/UNSW_filtered optimised.csv")# Read the dataset from a CSV file into a pandas DataFrame.
data.dropna(inplace=True)
data.drop(columns=['ts', 'uid', 'id.orig_h', 'id.orig_p', 'id.resp_h', 'id.resp_p','history','tunnel_parents'], inplace=True)
filtered_data = data[data["attack_cat"].isin(["Normal", "DoS", "Portscan"])]  
attack_mapping = {"Normal": 0, "DoS": 1, "Portscan": 2}
filtered_data["label"] = data["attack_cat"].map(attack_mapping)
data=filtered_data  #9 features
# Sélection des caractéristiques (suppression des colonnes non pertinentes ou redondantes)
X = data.drop(columns=["attack_cat", "label"])  
# `id` : Un identifiant unique pour chaque ligne, non pertinent pour la classification.
# `attack_cat` : Une étiquette décrivant le type d'attaque, utile dans certains contextes, mais ici on le supprime.
# `label` : La colonne cible (0 = normal, 1 = attaque) sera séparée pour devenir `y`.

y = data["label"]  # Extraire les étiquettes cibles (normal ou attaque) dans une variable séparée `y`.

# Encodage des caractéristiques catégorielles si elles existent
X = pd.get_dummies(X, columns=['proto', 'service', 'conn_state','local_resp','local_orig'], drop_first=True)
# Convertir les colonnes catégorielles de `X` en format numérique avec l'encodage one-hot.
# Cela crée de nouvelles colonnes binaires pour chaque valeur unique des caractéristiques catégorielles.
# Save the training feature columns
feature_columns = X.columns.tolist()
# Save this list to a file for later use
file_path = r'\Users\Administrator\Downloads\PDD/final model/features.pkl'  # Specify the desired path
with open(file_path, 'wb') as file:
    pickle.dump(feature_columns, file)


le = LabelEncoder()  
# Initialiser un encodage d'étiquettes pour convertir les étiquettes cibles en format numérique si nécessaire.

y = le.fit_transform(y)  
# Transformer les étiquettes (`y`) en format numérique (facultatif ici car les données sont déjà binaires).

# Diviser le jeu de données en ensembles d'entraînement et de test
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)  
# Diviser `X` et `y` en deux ensembles : 70% pour l'entraînement, 30% pour le test.
# `random_state=42` garantit la reproductibilité des résultats.

# Normalisation des données
scaler = StandardScaler()  # Initialiser un normaliseur (StandardScaler) pour standardiser les données.
X= scaler.fit_transform(X)  # Calculer les statistiques de normalisation sur l'ensemble d'entraînement et transformer les données.

file_path = r'\Users\Administrator\Downloads\PDD/final model/scaler.pkl'    
# Save the scaler for reuse in testing
with open(file_path, 'wb') as file:
    pickle.dump(scaler, file)

def add_noise(data, noise_level=0.2):
    noise = noise_level * np.random.normal(size=data.shape)
    return data + noise
X= add_noise(X, noise_level=0.5)  # Adjust `noise_level` as needed
# Initialisation et entraînement du modèle SVM
model = SVC(kernel="linear", C=1, random_state=42)  
# Créer un classifieur SVM avec un noyau linéaire. 
# `C=1` contrôle la régularisation (plus C est grand, moins il y a de régularisation).
# `random_state=42` garantit des résultats reproductibles.

model.fit(X, y)  
# Entraîner le modèle SVM sur les données d'entraînement (`X_train` et `y_train`).

# Évaluation du modèle
y_pred = model.predict(X)  
# Utiliser le modèle pour prédire les étiquettes sur l'ensemble de test.

print(confusion_matrix(y, y_pred))  
# Afficher la matrice de confusion pour analyser les prédictions du modèle.

print(classification_report(y, y_pred))  
# Afficher un rapport détaillé comprenant la précision, le rappel, le F1-score et l'accuracy.
# Calcul de la matrice de confusion en comparant les étiquettes réelles (y_test) avec les prédites (y_pred)
cm = confusion_matrix(y, y_pred)

# Affichage de la matrice de confusion avec un heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Normal', 'DOS', 'Portscan'], yticklabels=['Normal', 'DOS', 'Portscan'])
plt.xlabel('Prédictions')
plt.ylabel('Véritables étiquettes')
plt.title('Matrice de Confusion')
plt.show()


file_path = r'\Users\Administrator\Downloads\PDD/final model/model.pkl'
# Save the model to the specified location
with open(file_path, 'wb') as file:
    pickle.dump(model, file)
print(f"Model saved to {file_path}")

