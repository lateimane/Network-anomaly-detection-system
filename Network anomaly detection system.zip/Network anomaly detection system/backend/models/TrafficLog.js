const mongoose = require('mongoose');

const TrafficLogSchema = new mongoose.Schema({
    message: { type: String, required: true },
    type: { type: String, required: true },
    sourceIP: { type: String, required: true },
    timestamp: { type: Date, default: Date.now }, // Optionnel, pour suivre le moment de l'alerte
});

module.exports = mongoose.model('TrafficLog', TrafficLogSchema);

