const express = require("express");
const mongoose = require("mongoose");
const Alert = require("../models/TrafficLog");  // Importation du modèle TrafficLog
const axios = require('axios');
const router = express.Router();

// Route pour récupérer les alertes depuis Flask
router.post('/flask_alerts', async (req, res) => {
  try {
    const flaskApiUrl = 'http://127.0.0.1:5000/get_alerts';
    const response = await axios.get(flaskApiUrl);

    if (response.status === 200) {
      const alerts = response.data.alerts || [];

      const savedAlerts = [];
      
      // Log détaillé pour inspecter les données
      console.log("Données reçues de Flask:", JSON.stringify(alerts, null, 2));

      for (const alert of alerts) {
        const sourceIP = alert['id.orig_h']; // Vérifiez que le champ existe
        const type = alert['Predicted Attack Type']; // Vérifiez que le champ existe

        if (sourceIP && type) {
          // Log pour vérifier que les données sont correctes
          console.log("Enregistrement de l'alerte:", { sourceIP, type });

          const newAlert = new Alert({
            message: `Attaque détectée: ${type}`,
            type,
            sourceIP,
          });

          const savedAlert = await newAlert.save();
          savedAlerts.push(savedAlert);
        } else {
          console.error("Alerte invalide reçue de Flask:", alert);
        }
      }

      res.status(201).json({
        message: 'Alertes récupérées et sauvegardées avec succès',
        savedAlerts,
      });
    } else {
      res.status(response.status).json({ message: 'Erreur inattendue de l\'API Flask' });
    }
  } catch (error) {
    console.error("Erreur:", error.message);
    res.status(500).json({ error: error.message });
  }
});

// Route pour récupérer toutes les alertes depuis la base de donnée vers le frontend
router.get('/Alert', async (req, res) => {
    try {
        const alerts = await Alert.find();
        res.status(200).json(alerts);
    } catch (err) {
        res.status(500).json({ message: 'Erreur lors de la récupération des alertes', error: err.message });
    }
  });

  

    
  
  module.exports = router;
  
  