require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');
const mqttClient = require('./mqtt/mqttClient'); // Assurez-vous que ce fichier est correctement configuré
const apiRoutes = require('./routes/api'); // Vérifiez vos routes API
const cors = require('cors');
const flaskRoutes = require('./routes/api');
const app = express();
const PORT = process.env.PORT || 3000; // Utilisez une variable d'environnement pour le port

// Connecter à MongoDB
connectDB();

// Middleware
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:5000'], 
  methods: 'GET,POST,PUT,DELETE',
  credentials: true,
}));
app.use(express.json()); // Parse les requêtes en JSON

// Middleware pour capturer les erreurs JSON mal formés
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    console.error('Erreur de parsing JSON :', err.message);
    return res.status(400).json({ error: 'JSON invalide' });
  }
  next();
});

// Ajouter les routes API

app.use('/api/alerts', apiRoutes); // Préfixe toutes les routes avec /api
app.use('/api/trafficlogs', flaskRoutes);

// Gestion des routes inconnuesa
app.use((req, res, next) => {
  res.status(404).json({ message: 'Route non trouvée test' });
});

// Gestion des erreurs globales
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Erreur interne du serveur' });
});

// Démarrer le serveur
app.listen(PORT, () => console.log(`Serveur démarré sur http://localhost:${PORT}`));
