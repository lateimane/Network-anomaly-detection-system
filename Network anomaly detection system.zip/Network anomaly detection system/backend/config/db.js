require('dotenv').config();
const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connexion à MongoDB réussie");
  } catch (error) {
    console.error("Erreur lors de la connexion à MongoDB :", error);
    process.exit(1); // Quitte le processus en cas d'échec
  }
};

module.exports = connectDB;
