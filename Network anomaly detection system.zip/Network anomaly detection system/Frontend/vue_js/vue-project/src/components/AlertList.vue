<template>
  <div class="alert-list">
    <h2>Liste des alertes</h2>
    <ul>
      <li
        v-for="alert in paginatedAlerts"
        :key="alert.id"
        class="alert-item"
        @click="showSolution(alert.type)"
      >
        <span class="alert-message">{{ alert.message }}</span>
        <span class="alert-type">({{ alert.type }})</span>
      </li>
    </ul>

    <!-- Pagination -->
    <div class="pagination">
      <button
        :disabled="currentPage === 1"
        @click="currentPage--"
        class="page-btn"
      >
        Précédent
      </button>
      <span>Page {{ currentPage }} sur {{ totalPages }}</span>
      <button
        :disabled="currentPage === totalPages"
        @click="currentPage++"
        class="page-btn"
      >
        Suivant
      </button>
    </div>

    <!-- Boîte modale pour afficher la solution -->
    <div
      v-if="showModal"
      class="solution-modal"
      @click.self="closeModal"
    >
      <div class="modal-content">
        <h3>Solution pour {{ currentAlertType }}</h3>
        <p>{{ solutionMessage }}</p>
        <button class="close-btn" @click="closeModal">Fermer</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ['alerts'],
  data() {
    return {
      currentPage: 1, // Page actuelle
      itemsPerPage: 5, // Nombre d'alertes par page
      showModal: false,
      currentAlertType: '',
      solutionMessage: '',
    };
  },
  computed: {
    paginatedAlerts() {
      const start = (this.currentPage - 1) * this.itemsPerPage;
      const end = start + this.itemsPerPage;
      return this.alerts.slice(start, end); // Retourne un sous-ensemble des alertes
    },
    totalPages() {
      return Math.ceil(this.alerts.length / this.itemsPerPage); // Nombre total de pages
    },
  },
  methods: {
    showSolution(alertType) {
      this.currentAlertType = alertType;
      if (alertType === 'Portscan') {
        this.solutionMessage =
          'Activez un pare-feu pour surveiller et bloquer les connexions suspectes.';
      } else if (alertType === 'DoS') {
        this.solutionMessage =
          'Mettez en place des outils de mitigation DDoS et surveillez le trafic réseau.';
      } else {
        this.solutionMessage = 'Aucune solution spécifique disponible.';
      }
      this.showModal = true;
    },
    closeModal() {
      this.showModal = false;
    },
  },
};
</script>

<style scoped>
.alert-list {
  padding: 20px;
  background: white;
  border: 1px solid #ddd;
  border-radius: 8px;
  max-width: 100%;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.alert-list h2 {
  font-size: 1.7rem;
  font-weight: 700;
  margin-bottom: 20px;
  color: #0d0e10;
}

.alert-item {
  padding: 15px;
  margin: 10px 0;
  border: 1px solid #eee;
  border-radius: 6px;
  display: flex;
  justify-content: space-between;
  background: #f9f9f9;
  transition: background-color 0.3s ease, transform 0.2s ease,
    box-shadow 0.2s ease;
}

.alert-item:hover {
  background: #b71818;
  transform: translateY(-2px);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.pagination {
  color: #0d0e10;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
}

.page-btn {
  padding: 10px 15px;
  margin: 0 5px;
  background: #e61212;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.page-btn:disabled {
  background: #9c9c9c;
  cursor: not-allowed;
}

.solution-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  max-width: 400px;
  width: 100%;
  text-align: center;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}

.close-btn {
  margin-top: 20px;
  padding: 10px 20px;
  background: #b71818;
  color: rgb(255, 255, 255);
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.close-btn:hover {
  background: #a31515;
}
</style>