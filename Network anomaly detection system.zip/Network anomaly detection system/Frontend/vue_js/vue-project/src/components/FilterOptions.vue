<template>
  <div class="filter-options">
    <h3 class="filter-title">Filtrer par type d'anomalie</h3>
    <label for="filter" class="filter-label">Type d'anomalie :</label>
    <select @change="onFilterChange" id="filter" class="filter-select">
      <option value="all">Tous</option>
      <option v-for="type in anomalyTypes" :key="type" :value="type">{{ type }}</option>
    </select>
  </div>
</template>

<script>
export default {
  data() {
    return {
      anomalyTypes: ['DoS', 'Portscan']
    };
  },
  methods: {
    onFilterChange(event) {
      this.$emit('filter-change', event.target.value);
    }
  }
};
</script>

<style scoped>
.filter-options {
  padding: 20px;
  background-color: #868383;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  gap: 15px;
  max-width: 400px;
  margin: 0 auto;
}

.filter-title {
  font-size: 1.6rem;
  font-weight: 600;
  color: #090707;
}

.filter-label {
  font-size: 1.2rem;
  color: #171212;
  white-space: nowrap; /* Empêche le retour à la ligne */
}

.filter-select {
  padding: 12px;
  border: 1px solid #dddddd;
  border-radius: 6px;
  font-size: 1rem;
  color: #0c0505;
  background-color: #fbf8f8;
  transition: border-color 0.3s, background-color 0.3s;
}

.filter-select:hover {
  border-color: #007bff;
  background-color: #e42a2a;
}

.filter-select:focus {
  outline: none;
  border-color: #0056b3;
  box-shadow: 0 0 5px rgba(0, 86, 179, 0.5);
}
</style>
