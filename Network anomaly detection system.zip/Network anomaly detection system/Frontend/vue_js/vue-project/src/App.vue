<template>
  <router-view></router-view> <!-- C'est ici que le contenu des routes sera affiché -->
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
/* Ajoute tes styles globaux ici */
#app {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
}
</style>