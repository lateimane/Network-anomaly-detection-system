import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue'; // Importer le composant Home
import Dashboard from '../views/Dashboard.vue'; // Importer le composant Dashboard

const routes = [
    {
        path: '/',
        name: 'Home',
        component: Home // Route pour la page d'accueil
    },
    {
        path: '/dashboard',
        name: 'Dashboard',
        component: Dashboard // Route pour le tableau de bord
    }
];

const router = createRouter({
    history: createWebHistory(),
    routes
});

export default router;