<template>
  <div class="main-container">
    <!-- Navbar -->
    <nav class="navbar">
      <div class="site-name">ANOMDET</div>
      <ul>
        <li><a href="#home">Accueil</a></li>
        <li><a href="#about-us">À propos</a></li>
        <li><a href="#choose-plan">Nos Offres</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
    </nav>

    <h1>Bienvenue dans le Système de Détection d'Anomalies Réseau</h1>
    <p>Cette application vous permet de visualiser et de filtrer les alertes d'anomalies détectées sur le réseau.</p>

    <div v-if="!isLoggedIn">
      <button @click="showLoginForm = true" class="btn">Accéder au Tableau de Bord</button>
    </div>

    <div v-if="showLoginForm">
      <h2>Connexion</h2>
      <form @submit.prevent="handleLogin">
        <div>
          <label for="username">Nom d'utilisateur :</label>
          <input type="text" id="username" v-model="username" required />
        </div>
        <div>
          <label for="password">Mot de passe :</label>
          <input type="password" id="password" v-model="password" required />
        </div>
        <button type="submit" class="submit-btn">Se connecter</button>
      </form>
    </div>
    <div class="service-presentation">
    <!-- Introduction -->
    <div class="intro">
      <div class="white-line"></div>
      <h2>Présentation du service</h2>
      <div class="white-line"></div>
      <p style="font-size: 1rem; line-height: 1.6;">
        Notre système de détection d'anomalies réseau utilise des algorithmes avancés pour surveiller en temps réel votre infrastructure et identifier les comportements suspects. Grâce à cette solution, vous pouvez détecter et prévenir les anomalies avant qu'elles n'affectent votre réseau.
      </p>
    </div>

    <div>
    <!-- Section 1 - Surveillance continue et détection en temps réel -->
    <div class="service-section">
      <h3>Surveillance continue et détection en temps réel</h3>
      <div class="section-content">
        <div class="text-and-image">
          <p style="font-size: 1.1rem; line-height: 1.6;">
            Notre système assure une surveillance constante de vos flux de données pour détecter toute activité suspecte. Cela permet de réagir instantanément en cas de menace et d'éviter les dommages avant qu'ils n'affectent la performance du réseau.
          </p>
          <img src="@/assets/images/surveillance.jpg" alt="Surveillance continue" class="section-image" />
        </div>
      </div>
    </div>

    <!-- Section 2 - Prévention des attaques et optimisation des performances -->
    <div class="service-section">
      <h3>Prévention des attaques et optimisation des performances</h3>
      <div class="section-content">
        <div class="text-and-image">
          <p style="font-size: 1.1rem; line-height: 1.6;">
            En plus de la détection, notre service optimise la performance de votre réseau en analysant les anomalies et en identifiant les vulnérabilités avant qu'elles ne causent des interruptions, permettant ainsi de renforcer la sécurité de vos infrastructures.
          </p>
          <img src="@/assets/images/attaque.jpeg" alt="Prévention des attaques" class="section-image" />
        </div>
      </div>
    </div>

    <!-- Section 3 - Alertes personnalisées et rapports détaillés -->
    <div class="service-section">
      <h3>Alertes personnalisées et rapports détaillés</h3>
      <div class="section-content">
        <div class="text-and-image">
          <p style="font-size: 1.1rem; line-height: 1.6;">
            Recevez des alertes adaptées à vos besoins et des rapports détaillés sur chaque incident détecté. Ces rapports vous fournissent une vue approfondie de l'état de votre réseau et vous aident à réagir rapidement en cas de problème.
          </p>
          <img src="@/assets/images/alertes.jpg" alt="Alertes personnalisées" class="section-image" />
        </div>
      </div>
    </div>
  </div>

   
  </div>  




    <!-- Section À propos de nous -->
    <div id="about-us" class="about-us">
      <div class="white-line"></div>
      <h2>À propos de nous</h2>
      <div class="white-line"></div>

      <div class="about-item">
        <h3>Qui nous sommes</h3>
        <p style="font-size: 1rem; line-height: 1.6;">
          Nous sommes une équipe passionnée par l'innovation dans le domaine des réseaux et des technologies. Notre objectif est d'améliorer la sécurité et l'efficacité des infrastructures réseaux grâce à des solutions avancées de détection d'anomalies.
        </p>
      </div>

      <div class="about-item">
        <h3>Notre vision</h3>
        <p style="font-size: 1rem; line-height: 1.6;">
          Notre vision est de devenir un leader dans l'amélioration continue des systèmes de surveillance et de détection d'anomalies réseau, en offrant des outils simples mais puissants qui permettent aux entreprises de garantir la sécurité et la performance de leurs réseaux.
        </p>
      </div>

      <div class="about-item">
        <h3>Pourquoi nous choisir</h3>
        <p style="font-size: 1rem; line-height: 1.6;">
          Choisir notre solution, c'est opter pour un système fiable, intuitif et performant. Grâce à notre expertise et à notre technologie de pointe, nous assurons une détection rapide et précise des anomalies, permettant ainsi de prévenir les attaques et les pannes avant qu'elles n'affectent vos opérations.
        </p>
      </div>

      <div class="about-item">
        <h3>Rejoignez-nous</h3>
        <p style="font-size: 1rem; line-height: 1.6;">
          Si vous êtes passionné par la cybersécurité, les réseaux et l'innovation, nous serions ravis de vous accueillir dans notre équipe. Rejoignez-nous pour construire ensemble l'avenir de la détection d'anomalies réseau.
        </p>
      </div>
    </div>

    <!-- Section Choisissez votre plan -->
    <div id="choose-plan" class="choose-plan">
      <div class="white-line"></div>
      <h2>Choisissez votre plan</h2>
      <div class="white-line"></div>

      <div class="plan-container">
        <!-- Plan de départ (gratuit) -->
        <div class="plan">
          <h3>Plan de départ</h3>
          <p>Prix : <strong>Gratuit</strong></p>
          <ul>
            <li>Surveillance réseau de base</li>
            <li>Alertes limitées</li>
            <li>Support communautaire</li>
          </ul>
          <button class="btn" @click="scrollToLoginForm">Choisir ce plan</button>
        </div>

        <!-- Plan professionnel -->
        <div class="plan">
          <h3>Plan professionnel</h3>
          <p>Prix : <strong>49€/mois</strong></p>
          <ul>
            <li>Surveillance avancée</li>
            <li>Alertes illimitées</li>
            <li>Support prioritaire</li>
          </ul>
          <button class="btn" disabled>Indisponible</button>
        </div>

        <!-- Plan entreprise -->
        <div class="plan">
          <h3>Plan entreprise</h3>
          <p>Prix : <strong>99€/mois</strong></p>
          <ul>
            <li>Surveillance personnalisée</li>
            <li>Rapports détaillés</li>
            <li>Support dédié 24/7</li>
          </ul>
          <button class="btn" disabled>Indisponible</button>
        </div>
      </div>
    </div>

    <!-- Section Support et Contact en bas -->
    <div id="contact" class="footer-container">
      <!-- Section Support -->
      <div class="footer-item">
        <h2>Support</h2>
        <ul>
          <li>Email : <a href="mailto:support@example.com">support@example.com</a></li>
          <li>Téléphone : <a href="tel:+123456789">+123 456 789</a></li>
        </ul>
      </div>

      <!-- Section Réseaux Sociaux -->
      <div class="footer-item">
        <h2>Suivez-nous</h2>
        <ul>
          <li><a href="https://facebook.com" target="_blank">Facebook</a></li>
          <li><a href="https://twitter.com" target="_blank">Twitter</a></li>
          <li><a href="https://linkedin.com" target="_blank">LinkedIn</a></li>
        </ul>
      </div>

      <!-- Section Contact -->
      <div class="footer-item">
        <h2>Contact</h2>
        <ul>
          <li>Email : <a href="mailto:contact@example.com">contact@example.com</a></li>
          <li>Téléphone : <a href="tel:+987654321">+987 654 321</a></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
      showLoginForm: false,
      username: '',
      password: '',
      isLoggedIn: false
    };
  },
  methods: {
    handleLogin() {
      if (this.username === 'admin' && this.password === 'password') {
        this.isLoggedIn = true;
        this.$router.push('/dashboard');
      } else {
        alert('Nom d\'utilisateur ou mot de passe incorrect.');
      }
    },
    scrollToLoginForm() {
      this.showLoginForm = true;
      this.$nextTick(() => {
        const loginForm = this.$el.querySelector('form');
        loginForm.scrollIntoView({ behavior: 'smooth' });
      });
    }
  }
};
</script>

<style scoped>
.main-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.navbar {
  background-color: #05101c;
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.navbar .site-name {
  color: #FFD700;
  font-size: 1.8em;
  font-weight: bold;
}

.navbar ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  justify-content: center;
}

.navbar ul li {
  margin-right: 20px;
}

.navbar ul li:last-child {
  margin-right: 0;
}

.navbar ul li a {
  color: white;
  text-decoration: none;
  font-size: 1.2em;
}

.service-section h3 {
  color: #FFD700; /* Change la couleur en doré */
}

.text-and-image {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.text-and-image p {
  flex: 1;
  margin-right: 10px; /* espace entre le texte et l'image */
}

.text-and-image img {
  width: 40%; /* Ajustez la taille de l'image selon vos besoins */
  height: auto;
}

.service-section {
  margin-bottom: 40px;
}

h3 {
  font-size: 2.4em;
  margin-bottom: 10px;
}

.navbar ul li a:hover {
  text-decoration: underline;
}

.main-container h1, .main-container p {
  color: white;
}

.btn, .submit-btn {
  margin-top: 20px;
  padding: 10px 15px;
  background-color: rgb(218, 59, 59);
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
.intro h2 {
  text-align: center;
  margin-bottom: 10px;
  color: white;
  font-size: 2.6em;
}

form {
  margin-top: 20px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input {
  margin-bottom: 10px;
  padding: 5px;
  width: 250px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.submit-btn {
  padding: 8px 12px;
}

.about-us h2 {
  text-align: center;
  margin-bottom: 10px;
  color: white;
  font-size: 2.6em;
}

.white-line {
  width: 100%;
  height: 2px;
  background-color: white;
  margin: 10px 0;
}

.about-item {
  margin-bottom: 20px;
}
.service-presentation .intro {
  text-align: center;  /* Centrer tout le contenu de la présentation du service */
}
.about-item h3 {
  color: #FFD700;
}

.choose-plan {
  margin-top: 40px;
  text-align: center;
}

.choose-plan h2 {
  font-size: 2.6em;
  color: white;
}

.plan-container {
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
}

.plan {
  background-color: #05101c;
  padding: 20px;
  width: 30%;
  border: 1px solid #ccc;
  border-radius: 8px;
  color: white;
}

.plan h3 {
  color: #FFD700;
  margin-bottom: 10px;
}

.plan p {
  font-size: 1.2em;
  margin: 10px 0;
}

.plan ul {
  list-style-type: none;
  padding: 0;
}

.plan ul li {
  margin-bottom: 10px;
}

.plan .btn {
  margin-top: 15px;
  background-color: rgb(218, 59, 59);
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.plan .btn[disabled] {
  background-color: gray;
  cursor: not-allowed;
}

.footer-container {
  display: flex;
  justify-content: space-between;
  padding: 20px;
  background-color: #05101c;
  margin-top: 30px;
  border-top: 1px solid #ddd;
}

.footer-item {
  width: 30%;
}

.footer-item h2 {
  color: white;
}

.footer-item a {
  color: #9e9894;
  text-decoration: none;
}

.footer-item a:hover {
  text-decoration: underline;
}

.footer-item li {
  color: #c4c0c0;
}
</style>