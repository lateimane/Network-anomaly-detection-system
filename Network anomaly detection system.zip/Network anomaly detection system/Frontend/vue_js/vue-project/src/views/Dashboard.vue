<template>
  <div class="dashboard">
    <!-- En-tête du tableau de bord -->
    <header class="header">
      <h1>Tableau de bord des anomalies</h1>
      <!-- Bouton de déconnexion -->
      <button @click="logout" class="logout-btn">Déconnexion</button>
    </header>
    
    <!-- Contenu principal -->
    <div class="content">
      <!-- Section de filtrage -->
      <aside class="filter">
        <FilterOptions @filter-change="applyFilter" />
      </aside>

      <!-- Section des alertes -->
      <main class="main-content">
        <section class="alert-section">
          <AlertList :alerts="filteredAlerts" />
        </section>
      </main>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import AlertList from '../components/AlertList.vue'; 
import FilterOptions from '../components/FilterOptions.vue'; 

export default {
  data() {
    return {
      alerts: [],
      filteredAlerts: [],
    };
  },
  components: {
    AlertList,
    FilterOptions,
  },
  methods: {
    async fetchData() {
      try {
        const response = await axios.get('http://localhost:3000/api/alerts/Alert');
        console.log(response.data)
        this.alerts = response.data; 
        this.filteredAlerts = this.alerts; 
      } catch (error) {
        console.error('Erreur lors de la récupération des données :', error);
      }
    },
    applyFilter(filterType) {
      this.filteredAlerts =
        filterType === 'all'
          ? this.alerts
          : this.alerts.filter(alert => alert.type === filterType);
    },
    logout() {
      this.$router.push('/'); 
    }
  },
  mounted() {
    this.fetchData(); 
  }
};
</script>

<style scoped>
/* Général pour tout le tableau de bord */
.dashboard {
  font-family: 'Roboto', sans-serif;
  background-color: #464646;
  color: #333;
  padding: 10px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  margin: 0;
  height: 100vh; /* S'assurer que le tableau de bord occupe toute la hauteur de la page */
  width: 100%; /* S'assurer que le tableau de bord occupe toute la largeur de la page */
  display: flex;
  flex-direction: column; /* Disposition verticale */
  justify-content: space-between;
}

/* En-tête du tableau de bord */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #686d71;
  padding: 20px;
  border-radius: 8px;
  color: rgb(2, 2, 2);
  margin-bottom: 30px;
}

.header h1 {
  font-size: 1.8rem; 
  font-weight: 600;
}

.logout-btn {
  background-color: #dc3545;
  color: white;
  border: none;
  padding: 12px 25px; 
  font-size: 1.1rem;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.logout-btn:hover {
  background-color: #c82333;
}

/* Contenu principal */
.content {
  display: flex;
  gap: 30px;
  justify-content: space-between;
  flex-wrap: wrap;
  flex-grow: 1; /* Permet au contenu de s'étendre et remplir l'espace restant */
}

/* Zone de filtrage */
.filter {
  flex: 1;
  padding: 20px; 
  background: #636060;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  max-width: 300px; 
}

/* Zone des alertes */
.main-content {
  flex: 3;
  display: flex;
  flex-direction: column;
  gap: 20px;
  max-width: 1000px; 
}

/* Liste des alertes */
.alert-list {
  padding: 20px; 
  background-color: #767474;
  border-radius: 8px;
  border: 1px solid #ddd;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.alert-item {
  padding: 12px;
  margin-bottom: 12px;
  background-color: #f9f9f9;
  border-radius: 6px;
  border: 1px solid #eee;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s ease, transform 0.3s ease;
}

.alert-item:hover {
  background-color: #f1f1f1;
  transform: translateY(-2px);
}

/* Section de filtre */
.filter-options {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.filter-title {
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 8px;
}

.filter-label {
  font-size: 1rem;
  color: #555;
}

.filter-select {
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  transition: border-color 0.3s, box-shadow 0.3s;
}

.filter-select:hover {
  border-color: #007bff;
}

.filter-select:focus {
  outline: none;
  border-color: #0056b3;
  box-shadow: 0 0 5px rgba(0, 86, 179, 0.5);
}
</style>